from flask import Flask
from data import db_session
from data.users import User

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def main():
    db_session.global_init("db/mars_explorer.sqlite")
    session = db_session.create_session()

    user = User()
    user.surname = "Scott"
    user.name = "Ridley"
    user.age = 21
    user.position = "captain"
    user.speciality = "research engineer"
    user.address = "module_1"
    user.email = "scott_chief@mars.org"
    user.hashed_password = "cap"
    user.set_password(user.hashed_password)
    session.add(user)

    user2 = User()
    user2.surname = "Hughes"
    user2.name = "Adam"
    user2.age = 27
    user2.position = "sailor"
    user2.speciality = "engineer"
    user2.address = "module_2"
    user2.email = "adamadam@mars.org"
    user2.hashed_password = "coolman"
    user2.set_password(user2.hashed_password)
    session.add(user2)

    user3 = User()
    user3.surname = "Sparrow"
    user3.name = "Jack"
    user3.age = 20
    user3.position = "kok"
    user3.speciality = "cooker"
    user3.address = "galley"
    user3.email = "kokjack@mars.org"
    user3.hashed_password = "bestkok"
    user3.set_password(user3.hashed_password)
    session.add(user3)

    user4 = User()
    user4.surname = "Nilsen"
    user4.name = "Aleksandr"
    user4.age = 27
    user4.position = "tourist"
    user4.speciality = "businessman"
    user4.address = "module_1"
    user4.email = "host_of_the_world@mars.org"
    user4.hashed_password = "amazingme"
    user4.set_password(user4.hashed_password)
    session.add(user4)

    session.commit()


if __name__ == '__main__':
    main()
